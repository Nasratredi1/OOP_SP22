package Terminal;

interface calculate {
    int calculate(int item);
}

class displayA implements calculate {
    public int calculate(int item) {
        return item * 4;
    }
}

class displayB implements calculate {
    public int calculate(int item) {
        return item / 4;
    }
}


public class interfaceTest {

    public static void main(String[] args) {
        displayA a1 = new displayA();
        displayB b1 = new displayB();

        System.out.println(a1.calculate(4) + " and " + b1.calculate(4));
    }


    }


