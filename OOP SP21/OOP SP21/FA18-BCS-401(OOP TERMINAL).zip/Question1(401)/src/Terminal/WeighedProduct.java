package Terminal;

public class WeighedProduct extends Product{
    private float weightInKg;

    private WeighedProduct(float weight, String name, float price) {
        super(1, name, price);
        this.weightInKg = weight;
    }

    public float getPrice() {
        return this.weightInKg * super.getPrice();
    }


}
