package Terminal;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Main {
    public static float billTotal(ArrayList<Product> products) {
        float sum = 0;
        for (Product prod: products) {
            sum += prod.getPrice();
        }
        return sum;
    }

    public static void writeProduct(ArrayList<Product> products) {
        try {
            FileOutputStream fos = new FileOutputStream("products.txt");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(products);
            oos.close();
        } catch (IOException ioe) {
            System.out.println("Error writing to file: " + ioe);
        }
}
