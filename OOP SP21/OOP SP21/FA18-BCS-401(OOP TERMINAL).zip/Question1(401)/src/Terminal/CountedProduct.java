package Terminal;

public class CountedProduct extends Product{
    private float quantity;

    private CountedProduct(float quantity, String name, float price) {
        super(1, name, price);
        this.quantity = quantity;
    }

    public float getPrice() {
        return this.quantity * super.getPrice();
    }


}
