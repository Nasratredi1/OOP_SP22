package Terminal;

public class Product {
    private int id;
    private String name;
    private float price;

    protected Product(int id, String name, float price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public float getPrice() {
        return price;
    }

    public String toString() {
        return this.name;
    }

}

