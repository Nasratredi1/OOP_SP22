package Terminal;


import java.sql.SQLOutput;
import java.util.ArrayList;

public class ProductTest {

    public static void main(String[] args) {
        ArrayList<Product> bill = new ArrayList<Product>();
        bill.add(new WeighedProduct(1.37,"Rice",3.00));
        bill.add(new CountedProduct(1.37,"Rice",3.00));
        bill.add(new WeighedProduct(1.37,"Rice",3.00));
        System.out.println(billTotal(bill));
        ArrayList<CountedProduct> cp = new ArrayList<CountedProduct>();
        cp.add(new CountedProduct(10,"Pens",4,5));
        cp.add(new CountedProduct(10,"Pens",20));
        System.out.println(billTotal(cp));
        ArrayList<WeighedProduct> Wp = new ArrayList<WeighedProduct>();
        Wp.add(new WeighedProduct(1.37,"Rice",3.00));
        System.out.println(billTotal(Wp));

        WriteProduct(bill.args);



    }
}
