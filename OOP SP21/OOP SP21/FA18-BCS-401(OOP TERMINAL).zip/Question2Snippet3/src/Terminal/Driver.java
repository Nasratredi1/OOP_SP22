package Terminal;

public class Driver {
    static final int assign = 10;
    public static void main(String[] args) {

        Driver f =  new Driver();
        System.out.println(access(assign));
        }

        static int access(int assign) {
            return assign + 5;
        }
}
