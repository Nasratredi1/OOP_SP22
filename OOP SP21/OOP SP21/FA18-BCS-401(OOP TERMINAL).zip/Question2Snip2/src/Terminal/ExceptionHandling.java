package Terminal;

public class ExceptionHandling {

    public static void main(String[] args) {
        try {
            System.out.print("Hello ");
            throwit();
        }
        catch (RuntimeException e) {
            System.out.print("Caught ");
        }
        finally {
            System.out.print("Finally ");
        }

        System.out.println("after");
    }
    public static void throwit() {
        System.out.print("throwit ");
        throw new RuntimeException();
    }
}
