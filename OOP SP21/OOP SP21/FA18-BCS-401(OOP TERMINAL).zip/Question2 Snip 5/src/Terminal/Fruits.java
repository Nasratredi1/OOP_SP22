package Terminal;

public class Fruits {

    public static void main(String[] args) {
        Mango ff = new Mango();
        System.out.print(ff.price + " " + ff.quantity);

    }
}
class Mango{
    public int quantity= 5;
    public double price = 500;

}
