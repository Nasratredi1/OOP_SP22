package Terminal;

public class Sub  extends Super {

    String gender;

    Sub(String name, int age, float height, String gender) {
        super(name, age, height);
        this.gender = gender;
    }

    public String toString() {
        return super.name + " " + super.age + " " + super.height + " " + gender;


    }
}
