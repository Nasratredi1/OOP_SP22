package Terminal;
class Super {
    protected String name; //
    protected int age; //
    protected float height;
    Super(String name, int age, float height) {
        this.name = name; //
        this.age = age; //
        this.height = height;
    }
}
public class Main {

    public static void main(String[] args) {

        Sub sub1 = new Sub("Ahmad", 25, 5.5f, "male");
        System.out.println(sub1);

    }
}
