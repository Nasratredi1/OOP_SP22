package mypizza.app;

import mypizza.pos.PointOfSale;
import mypizza.top.Topping;

import java.util.ArrayList;
import java.util.Scanner;

public class PizzaApplication {

    public static void main(String[] args) throws Exception {
        PointOfSale order;
        System.out.println("Available toppings\n01- Pepperoni\n02- Pineapple\n03- Tikka\n04- Corn\n05- Mushroom\n06- Fajita\n");
        System.out.println("enter Orders { -1 to discontinue} ");
        ArrayList<PointOfSale> todaysOrders = new ArrayList<>();
        int toppings = 0;
        boolean extraToppingState = false;
        boolean alergiesState = false;
        Scanner scanner = new Scanner(System.in);
        do{
            System.out.println("\nEnter no of toppings you want to add");
            toppings = scanner.nextInt();
            if(toppings != -1){
                System.out.println("Enter size {regular, medium, large} ");
                String size = scanner.next();
                System.out.println("Would you like to add any extra-toppings {Yes/No} ");
                char choice1 = scanner.next().toLowerCase().charAt(0);
                System.out.println("Would you like to add your allergies {Yes/No} ");
                char choice2 = scanner.next().toLowerCase().charAt(0);
                if(choice1 == 'y'){
                    extraToppingState = true;
                }
                if(choice2 == 'y'){
                    alergiesState = true;
                }
                if(extraToppingState && alergiesState){
                    System.out.println("Enter your desired extra-topping");
                    String extraTopping = scanner.next();
                    System.out.println("Enter your allergies");
                    String allergies = scanner.next();
                    order = new PointOfSale(size, toppings, extraTopping, allergies);
                }else if(extraToppingState){
                    System.out.println("Enter your desired extra-topping");
                    String extraTopping = scanner.next();
                    order = new PointOfSale(size, toppings, extraTopping);
                }else if(alergiesState){
                    System.out.println("Enter your allergies");
                    String allergies = scanner.next();
                    order = new PointOfSale(size, toppings, "none", allergies);
                }else{
                    order = new PointOfSale(size, toppings);
                }
                todaysOrders.add(order);
                order.showOrder();
                
            }
        }while(toppings != -1);
        int i = 1;

        System.out.println("Would you like to change request");

        for (PointOfSale orders: todaysOrders) {
            System.out.println("Order no: " + i);
            orders.showOrder();
            i++;
            System.out.println("\n\n");
        }



    }


}