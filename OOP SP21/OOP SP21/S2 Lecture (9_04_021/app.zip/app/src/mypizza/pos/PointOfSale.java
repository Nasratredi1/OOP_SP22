package mypizza.pos;
import mypizza.top.Topping;

import java.time.LocalDate;
import java.util.Scanner;

public class PointOfSale {

    private static String crust;
    String size;
    final int price;
    private static LocalDate orderDate;
    String extraTopping;
    String alergies;
    Topping pizzaTopping;
    LocalDate localDate;
    public PointOfSale(String size, int topping) {
        this.size = size;
        setToppingCombination(topping);
        extraTopping = "none";
        alergies = "none";
        orderDate = localDate.now();
        if(size.toLowerCase().equals("regular")){
            this.price = 250;
        }else if (size.toLowerCase().equals("medium")){
            this.price = 450;
        }else if (size.toLowerCase().equals("large")){
            this.price = 750;
        }else{
            this.price = 0;
        }
    }

    public PointOfSale(String size, int topping, String extraTopping) {
        this.size = size;
        setToppingCombination(topping);
        this.extraTopping = extraTopping;
        orderDate = localDate.now();
        alergies = "none";
        if(size.toLowerCase().equals("regular")){
            this.price = 250 + 100;
        }else if (size.toLowerCase().equals("medium")){
            this.price = 450 + 100;
        }else if (size.toLowerCase().equals("large")){
            this.price = 750 + 100;
        }else{
            this.price = 0;
        }
    }

    public PointOfSale(String size, int topping, String extraTopping, String alergies) {
        this.size = size;
        setToppingCombination(topping);
        this.extraTopping = extraTopping;
        this.alergies = alergies;
        orderDate = localDate.now();
        if(size.toLowerCase().equals("regular")){
            this.price = 250 + 120;
        }else if (size.toLowerCase().equals("medium")){
            this.price = 450 + 120;
        }else if (size.toLowerCase().equals("large")){
            this.price = 750 + 120;
        }else{
            this.price = 0;
        }
    }

    {
        LocalDate localDate = LocalDate.now();
        crust = "Regular Bread";
        orderDate = localDate;
        extraTopping = "none";
        alergies = "none";
    }

    public void setToppingCombination(int no){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Desired topping no: ");
        if(no == 1){
            pizzaTopping = new Topping(scanner.nextInt());
        }else if (no == 2){
            pizzaTopping = new Topping(scanner.nextInt(), scanner.nextInt());
        }else if (no == 3){
            pizzaTopping = new Topping(scanner.nextInt(), scanner.nextInt(), scanner.nextInt());
        }else if (no == 4){
            pizzaTopping = new Topping(scanner.nextInt(), scanner.nextInt(), scanner.nextInt(), scanner.nextInt());
        }else if (no == 5){
            pizzaTopping = new Topping(scanner.nextInt(), scanner.nextInt(), scanner.nextInt(), scanner.nextInt(), scanner.nextInt());
        }else if (no == 6){
            pizzaTopping = new Topping(scanner.nextInt(), scanner.nextInt(), scanner.nextInt(), scanner.nextInt(), scanner.nextInt(), scanner.nextInt());
        }
    }

    public void showOrder(){
        System.out.println("Topping: " + pizzaTopping.toppingCombination);
        System.out.println("Size: " + size);
        System.out.println("Crust: " + crust);
        System.out.println("OrderDate: " + orderDate);
        System.out.println("ExtraTopping: " + extraTopping);
        System.out.println("Alergies: " + alergies);
        System.out.println("Price: " + price);

    }

    public void changeRequest(){
        System.out.println("01- change topping");
        System.out.println("02- change size");
        System.out.println("03- add/remove allergies");
        System.out.println("04- change ");
    }
}
