package mypizza.top;

public class Topping {
    public String toppingCombination;
    private final String toppingPepperoni;
    private final String toppingPineapple;
    private final String toppingTikka;
    private final String toppingCorn;
    private final String toppingMushroom;
    private final String toppingFajita;

    {
        toppingCombination = "ComboDeal";
        toppingPepperoni = "Pepperoni";
        toppingPineapple = "Pineapple";
        toppingTikka = "Tikka";
        toppingCorn = "Corn";
        toppingMushroom = "Mushroom";
        toppingFajita = "Fajita";
    }

    private String returnTopping(int a){
        if(a == 1){
            return toppingPepperoni;
        }else if(a == 2){
            return toppingPineapple;
        }else if(a == 3){
            return toppingTikka;
        }else if(a == 4){
            return toppingCorn;
        }else if(a == 5){
            return toppingMushroom;
        }else if(a == 6){
            return toppingFajita;
        }
        return "none";
    }

    public Topping(int a){
        toppingCombination = returnTopping(a);
    }

    public Topping(int a, int b){
        toppingCombination = returnTopping(a) + " + " + returnTopping(b);
    }

    public Topping(int a, int b, int c){
        toppingCombination = returnTopping(a) + " + " + returnTopping(b) + " + " + returnTopping(c);
    }

    public Topping(int a, int b, int c, int d){
        toppingCombination = returnTopping(a) + " + " + returnTopping(b) + " + " + returnTopping(c) + " + " + returnTopping(d);
    }

    public Topping(int a, int b, int c, int d, int e){
        toppingCombination = returnTopping(a) + " + " + returnTopping(b) + " + " + returnTopping(c) + " + " + returnTopping(d) + " + " + returnTopping(e);
    }

    public Topping(int a, int b, int c, int d, int e, int f){
        toppingCombination = returnTopping(a) + " + " + returnTopping(b) + " + " + returnTopping(c) + " + " + returnTopping(d) + " + " + returnTopping(e) + " + " + returnTopping(f);
    }
}