import java.util.ArrayList;
import java.util.Scanner;

public class RegisterEmployee {
    Scanner scanner = new Scanner(System.in);

    // Arraylists to store Data/Record
    ArrayList<Employee> employeeArrayList = new ArrayList<>();
    ArrayList<NonEmployee> nonEmployeeArrayList = new ArrayList<>();

    // add new Employee or non Employee
    public void addNew(){
        // variables
        int choice;
        String name;
        String id = null;
        String email = null;
        Employee employee;
        NonEmployee nonEmployee;

        System.out.println("Select Employee Type");
        System.out.println("01 --> Faculty\n02 --> Admin\n03 --> Fixed Pay\n04 --> Daily Wage");
        choice = Integer.parseInt(scanner.nextLine());
        // getting info
        System.out.println("Enter Name: ");
        name = scanner.nextLine();

        // No need for this info for Daily wages since they are not an employee
        if(choice != 4){
            System.out.println("Enter ID: ");
            id = scanner.nextLine();
            System.out.println("Enter Email: ");
            email = scanner.nextLine();
        }
        if(choice == 1){
            employee = new Faculty(name, id, email);
            employeeArrayList.add(employee);
        }else if(choice == 2){
            employee = new Admin(name, id, email);
            employeeArrayList.add(employee);
        }else if( choice == 3){
            employee = new FixedPay(name, id, email);
            employeeArrayList.add(employee);
        }else if( choice == 4){
            nonEmployee = new DailyWages(name);
            nonEmployeeArrayList.add(nonEmployee);
        }else{
            System.out.println("invalid argument");
        }
    }

    public void showEmployeeRecords(){
        for (Employee employee: employeeArrayList) {
            System.out.println("Name: " + employee.getName());
            System.out.println("ID: " + employee.getId());
            System.out.println("Email: " + employee.getEmail());
            if(employee instanceof Faculty){
                System.out.println("Travel Allowance: " + ((Faculty) employee).getTravelAllowance());
                System.out.println("Dinner Allowance: " + ((Faculty) employee).getDinerAllowance());
                System.out.println("Salary: " + ((Faculty) employee).calcSalary());
            }else if(employee instanceof Admin){
                System.out.println("Travel Allowance: " + ((Admin) employee).getTravelAllowance());
                System.out.println("Salary: " + ((Admin) employee).calcSalary());
            }else if(employee instanceof FixedPay){
                System.out.println("No of Lectures: " + ((FixedPay) employee).getLectures());
                System.out.println("Salary: " + ((FixedPay) employee).calcSalary());
            }
            System.out.println("..._______________________...");
        }
    }

    public void showNonEmployeeRecords(){
        for (NonEmployee nonEmployee: nonEmployeeArrayList) {
            System.out.println("Name: " + nonEmployee.getName());
            if(nonEmployee instanceof DailyWages){
                System.out.println("Salary: " + ((DailyWages) nonEmployee).calcSalary());
            }
            System.out.println("..._______________________...");
        }
    }
}
