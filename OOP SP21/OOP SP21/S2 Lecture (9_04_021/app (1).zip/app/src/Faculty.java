import java.util.Scanner;

public class Faculty extends Employee implements SalaryEmployee {

    private int travelAllowance;
    private int dinerAllowance;
    private static final double basicPay = 30000;

    public Faculty(String name, String id, String email) {
        super(name, id, email);
        setTravelAllowance();
        setDinerAllowance();
    }

    @Override
    public double calcSalary() {
        int basicPayPercentage = (int)(basicPay*(80.0f/100.0f));
        return basicPayPercentage + getDinerAllowance() + getTravelAllowance();
    }

    @Override
    public void setTravelAllowance() {
        System.out.println("Enter Travel Distance (Km): ");
        Scanner scanner = new Scanner(System.in);
        double distance = Double.parseDouble(scanner.nextLine());
        this.travelAllowance = (int) (3 * distance);
    }

    @Override
    public void setDinerAllowance() {
        System.out.println("Enter Expense: ");
        this.dinerAllowance = Integer.parseInt(new Scanner(System.in).nextLine());
    }

    @Override
    public int getTravelAllowance() {
        return travelAllowance;
    }

    @Override
    public int getDinerAllowance() {
        return dinerAllowance;
    }


}
