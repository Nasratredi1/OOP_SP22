import java.util.InvalidPropertiesFormatException;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        RegisterEmployee registerEmployee = new RegisterEmployee();
        int choice = 0;
        do{
            System.out.println("COMSATS University Islamabad");
            System.out.println("01 --> Add new Employee or worker\n02 --> Show Records\n03 Exit");
            choice = Integer.parseInt(scanner.nextLine());
            if(choice == 1){
                registerEmployee.addNew();
            }else if(choice == 2){
                System.out.println("====================");
                System.out.println("COMSATS Employees");
                System.out.println("====================");
                registerEmployee.showEmployeeRecords();
                System.out.println("====================");
                System.out.println("COMSATS Non-Employees");
                System.out.println("====================");
                registerEmployee.showNonEmployeeRecords();
            }else if(choice == 3){
                break;
            }else {
                System.out.println("Invalid Argument");
            }
        }while(choice != 3);
    }
}
