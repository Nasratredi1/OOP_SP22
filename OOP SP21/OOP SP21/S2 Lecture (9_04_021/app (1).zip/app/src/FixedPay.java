import java.util.Scanner;

public class FixedPay extends Employee implements SalaryEmployee {
    private int lectures;
    private static final double basicPay = 1800;


    public FixedPay(String name, String id, String email) {
        super(name, id, email);
        setLectures();
    }

    public int getLectures() {
        return lectures;
    }

    public void setLectures() {
        System.out.println("Enter no of Lecture: ");
        this.lectures = Integer.parseInt(new Scanner(System.in).nextLine());
    }

    @Override
    public double calcSalary() {
        return basicPay * getLectures();
    }

    @Override
    public void setTravelAllowance() {}

    @Override
    public void setDinerAllowance() {}

    @Override
    public int getTravelAllowance() {
        return 0;
    }

    @Override
    public int getDinerAllowance() {
        return 0;
    }
}
