public interface SalaryNonEmployee {

    double calcSalary();
}
