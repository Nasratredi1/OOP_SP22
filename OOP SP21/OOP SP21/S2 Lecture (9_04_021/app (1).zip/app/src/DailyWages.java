public class DailyWages extends NonEmployee implements SalaryNonEmployee{

    public static final double fixedSalary = 700;
    public DailyWages(String name) {
        super(name);
    }

    @Override
    public double calcSalary() {
        return fixedSalary;
    }
}
