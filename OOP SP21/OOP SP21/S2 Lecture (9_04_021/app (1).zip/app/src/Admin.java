import java.util.Scanner;

public class Admin extends Employee implements SalaryEmployee {

    private int travelAllowance;
    private static final double basicPay = 40000;


    public Admin(String name, String id, String email) {
        super(name, id, email);
        setTravelAllowance();
    }

    @Override
    public double calcSalary() {
        int basicPayPercentage = (int)(basicPay*(80.0f/100.0f));
        return basicPayPercentage + getTravelAllowance();
    }

    @Override
    public void setTravelAllowance() {
        System.out.println("Enter Travel Distance (Km): ");
        Scanner scanner = new Scanner(System.in);
        double distance = Double.parseDouble(scanner.nextLine());
        this.travelAllowance = (int) (3* distance);
    }

    @Override
    public void setDinerAllowance() {}

    @Override
    public int getTravelAllowance() {
        return travelAllowance;
    }

    @Override
    public int getDinerAllowance() {
        return 0;
    }
}
