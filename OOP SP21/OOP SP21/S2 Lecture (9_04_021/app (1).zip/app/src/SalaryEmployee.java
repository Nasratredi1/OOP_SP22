public interface SalaryEmployee {

    void setTravelAllowance();
    void setDinerAllowance();
    int getTravelAllowance();
    int getDinerAllowance();
    double calcSalary();
}
